<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-gradient-to-r from-green-500 to-green-600 overflow-hidden shadow-lg sm:rounded-lg transform transition hover:scale-105">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-white">Total Sales</h3>
                        <p class="text-3xl font-bold text-white">₱{{ number_format($totalSales, 2) }}</p>
                    </div>
                </div>
                <div class="bg-gradient-to-r from-blue-500 to-blue-600 overflow-hidden shadow-lg sm:rounded-lg transform transition hover:scale-105">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-white">Number of Sales</h3>
                        <p class="text-3xl font-bold text-white">{{ number_format($salesCount) }}</p>
                    </div>
                </div>
                <div class="bg-gradient-to-r from-purple-500 to-purple-600 overflow-hidden shadow-lg sm:rounded-lg transform transition hover:scale-105">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-white">Average Sale</h3>
                        <p class="text-3xl font-bold text-white">₱{{ number_format($salesCount > 0 ? $totalSales / $salesCount : 0, 2) }}</p>
                    </div>
                </div>
                <div class="bg-gradient-to-r from-orange-500 to-orange-600 overflow-hidden shadow-lg sm:rounded-lg transform transition hover:scale-105">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-white">This Month</h3>
                        <p class="text-3xl font-bold text-white">₱{{ number_format($thisMonthSales ?? 0, 2) }}</p>
                    </div>
                </div>
            </div>

            <!-- Row 1: Monthly Sales at Daily Sales -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <!-- Monthly Sales Chart - Pinalitan ng line + bar combo -->
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg hover:shadow-2xl transition-shadow">
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-4 border-l-4 border-blue-500 pl-3">📊 Monthly Sales ({{ date('Y') }})</h3>
                        <canvas id="monthlySalesChart" width="400" height="200"></canvas>
                    </div>
                </div>

                <!-- Daily Sales Chart - May gradient at mas magandang design -->
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg hover:shadow-2xl transition-shadow">
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-4 border-l-4 border-green-500 pl-3">📈 Daily Sales (Last 7 Days)</h3>
                        <canvas id="dailySalesChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>

            <!-- Row 2: Comparison at Trend Analysis -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Year Comparison Chart - Area chart na may gradient -->
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg hover:shadow-2xl transition-shadow">
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-4 border-l-4 border-purple-500 pl-3">📅 Sales Comparison: {{ date('Y') }} vs {{ date('Y') - 1 }}</h3>
                        <canvas id="comparisonChart" width="400" height="200"></canvas>
                    </div>
                </div>

                <!-- Sales Distribution - Doughnut chart -->
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg hover:shadow-2xl transition-shadow">
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-gray-900 mb-4 border-l-4 border-red-500 pl-3">🍩 Sales Distribution</h3>
                        <canvas id="distributionChart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 1. Monthly Sales Chart - Gradient Bar Chart
            const monthlyCtx = document.getElementById('monthlySalesChart').getContext('2d');
            const gradient = monthlyCtx.createLinearGradient(0, 0, 0, 400);
            gradient.addColorStop(0, 'rgba(54, 162, 235, 0.8)');
            gradient.addColorStop(1, 'rgba(54, 162, 235, 0.3)');
            
            new Chart(monthlyCtx, {
                type: 'bar',
                data: {
                    labels: @json($labels),
                    datasets: [{
                        label: 'Monthly Sales',
                        data: @json($data),
                        backgroundColor: gradient,
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 2,
                        borderRadius: 10,
                        barPercentage: 0.65,
                        categoryPercentage: 0.8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                font: {
                                    size: 12,
                                    weight: 'bold'
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleColor: '#fff',
                            bodyColor: '#fff',
                            callbacks: {
                                label: function(context) {
                                    return '₱' + context.raw.toLocaleString();
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)',
                                drawBorder: false
                            },
                            ticks: {
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                },
                                font: {
                                    size: 11
                                }
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            },
                            ticks: {
                                font: {
                                    size: 11,
                                    weight: 'bold'
                                }
                            }
                        }
                    }
                }
            });

            // 2. Daily Sales Chart - Smooth Line with Gradient Fill
            const dailyCtx = document.getElementById('dailySalesChart').getContext('2d');
            const dailyGradient = dailyCtx.createLinearGradient(0, 0, 0, 400);
            dailyGradient.addColorStop(0, 'rgba(75, 192, 192, 0.6)');
            dailyGradient.addColorStop(1, 'rgba(75, 192, 192, 0.05)');
            
            new Chart(dailyCtx, {
                type: 'line',
                data: {
                    labels: @json($dailyLabels),
                    datasets: [{
                        label: 'Daily Sales Trend',
                        data: @json($dailyData),
                        backgroundColor: dailyGradient,
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: 'rgba(75, 192, 192, 1)',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 5,
                        pointHoverRadius: 8,
                        pointStyle: 'circle'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                font: {
                                    size: 12,
                                    weight: 'bold'
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            callbacks: {
                                label: function(context) {
                                    return 'Sales: ₱' + context.raw.toLocaleString();
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                }
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    },
                    interaction: {
                        mode: 'index',
                        intersect: false
                    }
                }
            });

            // 3. Year Comparison Chart - Line Chart with Smooth Curves
            const comparisonCtx = document.getElementById('comparisonChart').getContext('2d');
            new Chart(comparisonCtx, {
                type: 'line',
                data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                    datasets: [
                        {
                            label: '{{ date("Y") }}',
                            data: @json($currentYearData ?? array_fill(0, 12, 0)),
                            borderColor: 'rgba(54, 162, 235, 1)',
                            backgroundColor: 'rgba(54, 162, 235, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: true,
                            pointBackgroundColor: 'rgba(54, 162, 235, 1)',
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointRadius: 4,
                            pointHoverRadius: 6
                        },
                        {
                            label: '{{ date("Y") - 1 }}',
                            data: @json($lastYearData ?? array_fill(0, 12, 0)),
                            borderColor: 'rgba(255, 99, 132, 1)',
                            backgroundColor: 'rgba(255, 99, 132, 0.1)',
                            borderWidth: 3,
                            tension: 0.4,
                            fill: true,
                            pointBackgroundColor: 'rgba(255, 99, 132, 1)',
                            pointBorderColor: '#fff',
                            pointBorderWidth: 2,
                            pointRadius: 4,
                            pointHoverRadius: 6
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                font: {
                                    size: 12,
                                    weight: 'bold'
                                },
                                usePointStyle: true,
                                boxWidth: 10
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ₱' + context.raw.toLocaleString();
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            },
                            ticks: {
                                callback: function(value) {
                                    return '₱' + value.toLocaleString();
                                }
                            }
                        }
                    },
                    interaction: {
                        mode: 'index',
                        intersect: false
                    }
                }
            });

            // 4. Sales Distribution Chart - Doughnut Chart (gumagamit ng existing data)
            const distributionCtx = document.getElementById('distributionChart').getContext('2d');
            
            // I-compute ang distribution ng sales (kung may data)
            const monthlyData = @json($data);
            const labels = @json($labels);
            
            // Kunin ang top 5 months na may highest sales
            const monthlyWithLabels = labels.map((label, index) => ({
                label: label,
                value: monthlyData[index] || 0
            }));
            
            const sortedMonths = monthlyWithLabels.sort((a, b) => b.value - a.value);
            const top5Months = sortedMonths.slice(0, 5);
            const otherMonths = sortedMonths.slice(5);
            
            const otherTotal = otherMonths.reduce((sum, month) => sum + month.value, 0);
            
            const distributionLabels = top5Months.map(m => m.label);
            const distributionData = top5Months.map(m => m.value);
            
            if (otherTotal > 0) {
                distributionLabels.push('Others');
                distributionData.push(otherTotal);
            }
            
            new Chart(distributionCtx, {
                type: 'doughnut',
                data: {
                    labels: distributionLabels,
                    datasets: [{
                        data: distributionData,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.8)',
                            'rgba(54, 162, 235, 0.8)',
                            'rgba(255, 206, 86, 0.8)',
                            'rgba(75, 192, 192, 0.8)',
                            'rgba(153, 102, 255, 0.8)',
                            'rgba(255, 159, 64, 0.8)'
                        ],
                        borderWidth: 2,
                        borderColor: '#fff',
                        cutout: '55%',
                        hoverOffset: 15
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                font: {
                                    size: 11
                                },
                                generateLabels: function(chart) {
                                    const data = chart.data;
                                    if (data.labels.length && data.datasets.length) {
                                        return data.labels.map((label, i) => {
                                            const value = data.datasets[0].data[i];
                                            const total = data.datasets[0].data.reduce((a, b) => a + b, 0);
                                            const percentage = ((value / total) * 100).toFixed(1);
                                            return {
                                                text: `${label} (${percentage}%)`,
                                                fillStyle: data.datasets[0].backgroundColor[i],
                                                index: i
                                            };
                                        });
                                    }
                                    return [];
                                }
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = ((value / total) * 100).toFixed(1);
                                    return `${label}: ₱${value.toLocaleString()} (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
    @endpush
</x-app-layout>