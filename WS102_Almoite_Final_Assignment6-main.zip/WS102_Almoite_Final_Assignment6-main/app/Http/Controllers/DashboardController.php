<?php

namespace App\Http\Controllers;

use App\Models\Sale;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        // Fetch sales grouped by month
        $salesData = Sale::selectRaw('SUM(amount) as total, MONTHNAME(sale_date) as month')
            ->groupBy('month')
            ->orderBy('sale_date')
            ->get();
        
        $labels = $salesData->pluck('month');
        $data = $salesData->pluck('total');
        
        // Get daily sales for last 7 days
        $dailySales = Sale::selectRaw('DATE(sale_date) as date, SUM(amount) as total')
            ->where('sale_date', '>=', now()->subDays(7))
            ->groupBy('date')
            ->orderBy('date')
            ->get();
        
        $dailyLabels = $dailySales->pluck('date')->map(function($date) {
            return date('M d', strtotime($date));
        });
        
        $dailyData = $dailySales->pluck('total');
        
        // Get total sales and count
        $totalSales = Sale::sum('amount');
        $salesCount = Sale::count();
        
        // Pass all variables to the view
        return view('dashboard', compact('labels', 'data', 'dailyLabels', 'dailyData', 'totalSales', 'salesCount'));
    }
}