<?php

namespace Database\Seeders;

use App\Models\Sale;
use Illuminate\Database\Seeder;

class SalesTableSeeder extends Seeder
{
    public function run()
    {
        // Create sample sales for the past 12 months
        for ($month = 1; $month <= 12; $month++) {
            $date = date('Y-m-d', mktime(0, 0, 0, $month, 15, date('Y')));
            
            // Create 5-15 sales per month
            $salesCount = rand(5, 15);
            for ($i = 0; $i < $salesCount; $i++) {
                Sale::create([
                    'amount' => rand(50, 500),
                    'created_at' => $date,
                    'updated_at' => $date,
                ]);
            }
        }
        
        // Create daily sales for the past 7 days
        for ($day = 0; $day < 7; $day++) {
            $date = now()->subDays($day)->format('Y-m-d');
            $salesCount = rand(3, 10);
            for ($i = 0; $i < $salesCount; $i++) {
                Sale::create([
                    'amount' => rand(25, 300),
                    'created_at' => $date,
                    'updated_at' => $date,
                ]);
            }
        }
    }
}